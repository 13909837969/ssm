package com.company.service.iservice;

import java.util.List;

import com.company.dao.pojo.User;

public interface IUserService {
    String delete(User u);

    String save(User u);

    User findById(Integer id);

    String update(User u);

    List<User> findAll();
    
}