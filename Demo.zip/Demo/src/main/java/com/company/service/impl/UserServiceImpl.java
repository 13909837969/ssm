package com.company.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.company.dao.mapper.UserDao;
import com.company.dao.pojo.User;
import com.company.service.iservice.IUserService;
@Service("userService")
public class UserServiceImpl implements IUserService {

	@Autowired
	private UserDao us;
	
	@Override
	@Transactional
	public String delete(User u) {
		String msg = "error";
		try {
			msg = "success";
			us.deleteByPrimaryKey(u.getId());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return msg;
	}

	
	
	@Override
	@Transactional
	public String save(User u) {
		String msg = "error";
		try {
			msg = "success";
			us.insertSelective(u);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return msg;
	}

	@Override
	@Transactional
	public User findById(Integer id) {
		User u = null;
		try {
			u = us.selectByPrimaryKey(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Service:user  " + u);
		return u;
	}

	@Override
	@Transactional
	public String update(User u) {
		String msg = "error";
		try {
			msg = "success";
			us.updateByPrimaryKeySelective(u);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("service:"+msg);
		return msg;
	}

	@Override
	@Transactional
	public List<User> findAll() {
		List<User> list = null;
		try {
			list = us.findAll();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}

}
