package com.company.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.company.dao.pojo.User;
import com.company.service.iservice.IUserService;
@Controller
@RequestMapping("user")
public class UserAction 
{

	@Autowired
	@Qualifier("userService")
	private IUserService us;
	
	
	@RequestMapping(value="tianjia.do",method=RequestMethod.GET)
	public String tianjia()
	{
		return "save";
	}
	
	@RequestMapping(value="xiugai.do",method=RequestMethod.GET)
	public String xiugai()
	{
		return "xiugai";
	
	}
	
	
	@RequestMapping(value="delete.do",method=RequestMethod.GET)
	 String delete(User u)
	 {
		String msg = us.delete(u);
		return "redirect:/user/findAll.do"; 
	 }
	
	
	
	@RequestMapping(value="save.do",method=RequestMethod.GET)
	 String save(User u)
	 {
		String msg = us.save(u);
		return "redirect:/user/findAll.do" ; 
	 }

	
	
	@RequestMapping(value="update.do",method=RequestMethod.GET)
	 String update(User u)
	 {
		System.out.println(u+"user");
		 String msg = us.update(u);
		 System.out.println("user msg:"+msg);
		return "success".equals(msg) ? "redirect:/user/findAll.do" : "error" ; 
	 }
	
	
	@RequestMapping(value="findById.do",method=RequestMethod.GET)
	 String findById(@RequestParam Integer id)
	 {
		User msg = us.findById(id);
		return "findById"; 
	 }
	
	
	@RequestMapping(value="findAll.do",method=RequestMethod.GET)
	 String findAll(User u,Map<String,Object>map)
	 {
		List<User> msg = us.findAll();
		map.put("findAll", msg);
		return "findAll"; 
	 }
}